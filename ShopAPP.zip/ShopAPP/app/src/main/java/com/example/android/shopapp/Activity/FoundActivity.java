package com.example.android.shopapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.android.shopapp.R;

public class FoundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_found);
        bottomNavigetion();
    }

    private void bottomNavigetion() {
        LinearLayout homeBth = findViewById(R.id.homeBtn);
        LinearLayout cartBth = findViewById(R.id.cartBtn);
        LinearLayout foundBtn = findViewById(R.id.foundBtn);
        LinearLayout userBtn = findViewById(R.id.userBtn);
        LinearLayout typeBtn=findViewById(R.id.typeBtn);
        TextView AttentionBtn = findViewById(R.id.AttentionBtn);
        TextView RecommendBtn = findViewById(R.id.RecommendBtn);
        TextView TwelveBtn = findViewById(R.id.TwelveBtn);

        homeBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this, MainActivity.class));
            }
        });

        cartBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this, CartActivity.class));
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,UserActivity.class));
            }
        });


        foundBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,FoundActivity.class));
            }
        });

        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,TypeActivity.class));
            }
        });

        RecommendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,FoundActivity.class));
            }
        });

        AttentionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,FoundAttentionActivity.class));
            }
        });

        TwelveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundActivity.this,FoundTwelveActivity.class));
            }
        });
    }
}