package com.example.android.shopapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.android.shopapp.Adapter.AttentionAdapter;
import com.example.android.shopapp.Adapter.CategoryAdapter;
import com.example.android.shopapp.Domain.AttentionDomain;
import com.example.android.shopapp.Domain.CategoryDomain;
import com.example.android.shopapp.R;

import java.util.ArrayList;

public class FoundAttentionActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapter3;
    private RecyclerView recyclerViewAttentionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_found_attention);
        recyclerViewAttention();
        bottomNavigetion();
    }

    private void bottomNavigetion() {
        LinearLayout homeBth = findViewById(R.id.homeBtn);
        LinearLayout cartBth = findViewById(R.id.cartBtn);
        LinearLayout foundBtn = findViewById(R.id.foundBtn);
        LinearLayout userBtn = findViewById(R.id.userBtn);
        LinearLayout typeBtn=findViewById(R.id.typeBtn);
        TextView AttentionBtn = findViewById(R.id.AttentionBtn);
        TextView RecommendBtn = findViewById(R.id.RecommendBtn);
        TextView TwelveBtn = findViewById(R.id.TwelveBtn);

        homeBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this, MainActivity.class));
            }
        });

        cartBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this, CartActivity.class));
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,UserActivity.class));
            }
        });


        foundBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,FoundActivity.class));
            }
        });

        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,TypeActivity.class));
            }
        });

        RecommendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,FoundActivity.class));
            }
        });

        AttentionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,FoundAttentionActivity.class));
            }
        });

        TwelveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoundAttentionActivity.this,FoundTwelveActivity.class));
            }
        });
    }

    private void recyclerViewAttention(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewAttentionList=findViewById(R.id.view3);
        recyclerViewAttentionList.setLayoutManager(linearLayoutManager);

        ArrayList<AttentionDomain> attentionList = new ArrayList<>();
        attentionList.add(new AttentionDomain("特别呜啦啦","catt1"));
        attentionList.add(new AttentionDomain("白冰","catt2"));
        attentionList.add(new AttentionDomain("浪味仙","catt3"));
        attentionList.add(new AttentionDomain("麻辣德子","catt4"));
        attentionList.add(new AttentionDomain("张喜喜","catt5"));

        adapter3=new AttentionAdapter(attentionList);
        recyclerViewAttentionList.setAdapter(adapter3);
    }
}