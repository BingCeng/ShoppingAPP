package com.example.android.shopapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.android.shopapp.Adapter.CategoryAdapter;
import com.example.android.shopapp.Adapter.RecommendedAdapter;
import com.example.android.shopapp.Domain.CategoryDomain;
import com.example.android.shopapp.Domain.FoodDomain;
import com.example.android.shopapp.Helper.ManagementCart;
import com.example.android.shopapp.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private RecyclerView.Adapter adapter,adapter2;
private RecyclerView recyclerViewCategotyList, recyclerViewPopularList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewCategoty();
        recyclerViewPopular();
        bottomNavigetion();
    }

    //事件响应
    private void bottomNavigetion() {
        LinearLayout homeBth=findViewById(R.id.homeBtn);
        LinearLayout cartBth=findViewById(R.id.cartBtn);
        LinearLayout foundBtn=findViewById(R.id.foundBtn);
        LinearLayout userBtn=findViewById(R.id.userBtn);
        LinearLayout typeBtn=findViewById(R.id.typeBtn);


        homeBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });

        cartBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,CartActivity.class));
            }
        });


        foundBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,FoundActivity.class));
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,UserActivity.class));
            }
        });

        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,TypeActivity.class));
            }
        });
    }

    private void recyclerViewPopular(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewPopularList=findViewById(R.id.view2);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<FoodDomain> foodlist=new ArrayList<>();
        foodlist.add(new FoodDomain("饺子","dumplings","very good",13.0,5,20,1000));
        foodlist.add(new FoodDomain("烤鸡腿","roastedchd","very good",15.0,4,18,1500));
        foodlist.add(new FoodDomain("烤翅","roastedwings","very good",11.0,3,16,800));
        adapter2=new RecommendedAdapter(foodlist);
        recyclerViewPopularList.setAdapter(adapter2);
    }

    private void recyclerViewCategoty(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewCategotyList=findViewById(R.id.view1);
        recyclerViewCategotyList.setLayoutManager(linearLayoutManager);

        ArrayList<CategoryDomain> categoryList = new ArrayList<>();
        categoryList.add(new CategoryDomain("水果","cat_1"));
        categoryList.add(new CategoryDomain("主食","cat_2"));
        categoryList.add(new CategoryDomain("海鲜","cat_3"));
        categoryList.add(new CategoryDomain("饮料","cat_4"));
        categoryList.add(new CategoryDomain("点心","cat_5"));

        adapter=new CategoryAdapter(categoryList);
        recyclerViewCategotyList.setAdapter(adapter);
    }
}