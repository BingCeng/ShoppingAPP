package com.example.android.shopapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.android.shopapp.Adapter.RecommendedAdapter;
import com.example.android.shopapp.Domain.FoodDomain;
import com.example.android.shopapp.R;

import java.util.ArrayList;

public class TypeActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapter4;
    private RecyclerView  recyclerViewPopularList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type);
        recyclerViewFruits();
        recyclerViewSeafood();
        recyclerViewSnacks();
        recyclerViewSpices();
        bottomNavigetion();
    }

    //事件响应
    private void bottomNavigetion() {
        LinearLayout homeBth=findViewById(R.id.homeBtn);
        LinearLayout cartBth=findViewById(R.id.cartBtn);
        LinearLayout foundBtn=findViewById(R.id.foundBtn);
        LinearLayout userBtn=findViewById(R.id.userBtn);
        LinearLayout typeBtn=findViewById(R.id.typeBtn);
        ImageView ReturnBtn=findViewById(R.id.ReturnBtn);
        ImageView HomepageBtn=findViewById(R.id.HomepageBtn);

        homeBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this, MainActivity.class));
            }
        });

        cartBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,CartActivity.class));
            }
        });

        foundBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,FoundActivity.class));
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,UserActivity.class));
            }
        });

        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,TypeActivity.class));
            }
        });

        ReturnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,MainActivity.class));
            }
        });

        HomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TypeActivity.this,MainActivity.class));
            }
        });
    }

    private void recyclerViewFruits(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewPopularList=findViewById(R.id.view4);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<FoodDomain> foodlist=new ArrayList<>();
        foodlist.add(new FoodDomain("草莓","caomei","大凉山露天草莓\n果园直发新鲜到家",24.0,5,0,1000));
        foodlist.add(new FoodDomain("苹果","pingguo","山东烟台栖霞红富士苹果\n脆甜 甄选10一级大果",50.0,4,0,1500));
        foodlist.add(new FoodDomain("樱桃","yingtao","智利进口JJJ大樱桃",49.0,4,0,800));
        adapter4=new RecommendedAdapter(foodlist);
        recyclerViewPopularList.setAdapter(adapter4);
    }

    private void recyclerViewSeafood(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewPopularList=findViewById(R.id.view5);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<FoodDomain> foodlist=new ArrayList<>();
        foodlist.add(new FoodDomain("红花蟹","honghuaxie","大个鲜活红花蟹\n北京海鲜闪送",60.0,5,0,1000));
        foodlist.add(new FoodDomain("黑虎虾","heihuxia","销量20w+\n活冻黑虎虾超大",73.0,4,0,1500));
        foodlist.add(new FoodDomain("生蚝","shenghao","乳山生蚝鲜活即食",69.0,3,0,800));
        adapter4=new RecommendedAdapter(foodlist);
        recyclerViewPopularList.setAdapter(adapter4);
    }

    private void recyclerViewSnacks(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewPopularList=findViewById(R.id.view6);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<FoodDomain> foodlist=new ArrayList<>();
        foodlist.add(new FoodDomain("薯片","shupian","乐事薯片休闲零食",10.0,5,0,1000));
        foodlist.add(new FoodDomain("大礼包","dalibao","麻辣味网红小吃休闲零食大礼包",25.0,4,0,1500));
        foodlist.add(new FoodDomain("橡皮糖","xiangpitang","旺仔QQ橡皮糖",13.0,3,0,800));
        adapter4=new RecommendedAdapter(foodlist);
        recyclerViewPopularList.setAdapter(adapter4);
    }

    private void recyclerViewSpices(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewPopularList=findViewById(R.id.view7);
        recyclerViewPopularList.setLayoutManager(linearLayoutManager);

        ArrayList<FoodDomain> foodlist=new ArrayList<>();
        foodlist.add(new FoodDomain("酱油","jiangyou","海天生抽酱油\n中华老字号",14.0,5,0,1000));
        foodlist.add(new FoodDomain("花生油","huashengyou","金龙鱼 食用油 浓香花生油",74.0,4,0,1500));
        foodlist.add(new FoodDomain("黄豆酱","huangdoujiang","海天黄豆酱800g瓶\n实惠装家用",5.0,3,0,800));
        adapter4=new RecommendedAdapter(foodlist);
        recyclerViewPopularList.setAdapter(adapter4);
    }

}