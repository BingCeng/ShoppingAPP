package com.example.android.shopapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.android.shopapp.R;

public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        bottomNavigetion();
    }

    //事件响应
    private void bottomNavigetion() {
        LinearLayout homeBth = findViewById(R.id.homeBtn);
        LinearLayout cartBth = findViewById(R.id.cartBtn);
        LinearLayout foundBtn = findViewById(R.id.foundBtn);
        LinearLayout userBtn = findViewById(R.id.userBtn);
        LinearLayout typeBtn=findViewById(R.id.typeBtn);

        homeBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this, MainActivity.class));
            }
        });

        cartBth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this, CartActivity.class));
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this,UserActivity.class));
            }
        });


        foundBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this,FoundActivity.class));
            }
        });

        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this,TypeActivity.class));
            }
        });
    }
}