package com.example.android.shopapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.android.shopapp.Domain.AttentionDomain;
import com.example.android.shopapp.Domain.CategoryDomain;
import com.example.android.shopapp.R;

import java.util.ArrayList;

public class AttentionAdapter extends RecyclerView.Adapter<AttentionAdapter.ViewHolder> {
    ArrayList<AttentionDomain> attentionDomains;

    public AttentionAdapter(ArrayList<AttentionDomain> attentionDomains) {
        this.attentionDomains = attentionDomains;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_attention,parent,false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull AttentionAdapter.ViewHolder holder, int position) {
        holder.attentionName.setText(attentionDomains.get(position).getTitle());
        String picUrl="";
        switch (position){
            case 0:{
                picUrl = "catt1";
                break;
            }
            case 1:{
                picUrl = "catt2";
                break;
            }
            case 2:{
                picUrl = "catt3";
                break;
            }
            case 3:{
                picUrl = "catt4";
                break;
            }
            case 4:{
                picUrl = "catt5";
                break;
            }
        }
        int drawableReourceId = holder.itemView.getContext().getResources()
                .getIdentifier(picUrl,"drawable",
                        holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawableReourceId)
                .into(holder.attentionPic);
    }

    @Override
    public int getItemCount() {return attentionDomains.size();}

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView attentionName;
        ImageView attentionPic;
        ConstraintLayout secondmainLayout;
        public ViewHolder(@NonNull View itemview){
            super(itemview);
            attentionName = itemView.findViewById(R.id.attentionName);
            attentionPic = itemview.findViewById(R.id.attentionPic);
            secondmainLayout = itemview.findViewById(R.id.secondmainLayout);
        }
    }
}