package com.example.android.shopapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.android.shopapp.Domain.FoodDomain;
import com.example.android.shopapp.Helper.ManagementCart;
import com.example.android.shopapp.Interface.ChangeNumberltemsListener;
import com.example.android.shopapp.R;

import java.util.ArrayList;

public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.ViewHolder> {
    ArrayList<FoodDomain> listFoodSelected;
    private ManagementCart managementCart;
    ChangeNumberltemsListener changeNumberltemsListener;

    public CartListAdapter(ArrayList<FoodDomain> listFoodSelected, Context context, ChangeNumberltemsListener changeNumberltemsListener) {
        managementCart=new ManagementCart(context);
        this.listFoodSelected = listFoodSelected;
        this.changeNumberltemsListener=changeNumberltemsListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_cart,parent,false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(listFoodSelected.get(position).getTitle());
        holder.feeEachItem.setText("$"+listFoodSelected.get(position).getFee());
        holder.totalEachItem.setText("$"+Math.round(listFoodSelected.get(position).getNumberInCart())*listFoodSelected.get(position).getFee());
        holder.num.setText(String.valueOf(listFoodSelected.get(position).getNumberInCart()));


        int drawbleReourceId = holder.itemView.getContext().getResources()
                .getIdentifier(listFoodSelected.get(position).getPic(),"drawable",
                        holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawbleReourceId)
                .into(holder.pic);

        holder.plusItem.setOnClickListener(v -> managementCart.plusNumberFood(listFoodSelected, position, () -> {
            notifyDataSetChanged();
            changeNumberltemsListener.changed();
        }));

        holder.minusItem.setOnClickListener(v -> managementCart.minusNumberFood(listFoodSelected, position, () -> {
            notifyDataSetChanged();
            changeNumberltemsListener.changed();
        }));
    }

    @Override
    public int getItemCount() {return listFoodSelected.size();}

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView title, feeEachItem;
        ImageView pic,plusItem,minusItem;
        TextView totalEachItem,num;
        public ViewHolder(@NonNull View itemview){
            super(itemview);
            title = itemView.findViewById(R.id.titleTxt);
            pic = itemview.findViewById(R.id.pic);
            feeEachItem = itemview.findViewById(R.id.feeEachItem);
            totalEachItem = itemview.findViewById(R.id.totalEachItem);
            plusItem=itemview.findViewById(R.id.plusCardBtn);
            minusItem=itemview.findViewById(R.id.minusCardBtn);
            num=itemview.findViewById(R.id.numberItemTxt);
        }
    }
}
