package com.example.android.shopapp.Interface;

public interface ChangeNumberltemsListener {
    void changed();
}
